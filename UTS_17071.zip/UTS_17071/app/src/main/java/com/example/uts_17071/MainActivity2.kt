package com.example.uts_17071

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity3 : AppCompatActivity() {

    //key untuk ambil data dari kiriman Intent di activity 2
    companion object {
        const val EXTRA_NAME = "extra_title"
        const val EXTRA_LAYANAN = "extra_watchfor"
        const val EXTRA_MENU= "extra_menu"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main3)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val textReceivedName: TextView = findViewById(R.id.receivedName)
        val textReceivedLayanan: TextView = findViewById(R.id.receivedLayanan)
        val textReceivedMenu: TextView = findViewById(R.id.receivedMenu)

        //simpan data String dari kiriman intent ke dalam variabel
        val name = intent.getStringExtra(EXTRA_NAME)
        val layanan = intent.getStringExtra(EXTRA_LAYANAN)
        val menu = intent.getStringExtra(EXTRA_MENU)

        //mengganti teks pada TextView berdasarkan data yang dikirim dari activity 2
        textReceivedName.text = "Nama pemesan: $name"
        textReceivedLayanan.text = "Pilihan layanan: $layanan"
        textReceivedMenu.text = "Menu yang dipesan: $menu"

    }
}