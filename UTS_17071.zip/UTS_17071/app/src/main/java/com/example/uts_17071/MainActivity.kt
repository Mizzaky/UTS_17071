package com.example.uts_17071

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Spinner
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity2 : AppCompatActivity() {
    lateinit var edNama: EditText
    lateinit var btn:Button
    lateinit var title : String
    lateinit var watchfor: String
    lateinit var radiobuttonChecked: RadioButton
    lateinit var adult: RadioButton
    lateinit var kids: RadioButton
    lateinit var bgroup: RadioGroup
    lateinit var spinnerwatchfor: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        edNama = findViewById(R.id.title)
        btn = findViewById(R.id.btn)
        adult = findViewById(R.id.adult)
        kids = findViewById(R.id.kids)
        spinnerwatchfor = findViewById(R.id.spinnerwatchfor)
        bgroup = findViewById(R.id.bgroup)

        btn.setOnClickListener {
            //ambil teks dari RadioButton berdasarkan lingkup RadioGroup
            val selectedID = bgroup!!.checkedRadioButtonId
            radiobuttonChecked = findViewById(selectedID)
            title = radiobuttonChecked.text.toString()

            //ambil teks dari Spinner
            tekswatchfor = spinnerwatchfor.selectedItem.toString()

            val moveIntent = Intent(this@MainActivity, MainActivity2::class.java)
            moveIntent.putExtra(MainActivity2.EXTRA_TITLE,  edNama.text.toString())
            moveIntent.putExtra(MainActivity2.EXTRA_WATCHFOR, watchfor)
            moveIntent.putExtra(MainActivity2.EXTRA_GENRE, genre)
            startActivity(moveIntent)
        }

    }






}